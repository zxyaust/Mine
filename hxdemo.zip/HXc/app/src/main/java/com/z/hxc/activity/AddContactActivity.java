package com.z.hxc.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;

import com.hyphenate.chat.EMClient;
import com.hyphenate.exceptions.HyphenateException;
import com.z.hxc.R;
import com.z.hxc.utils.ToastUtil;

public class AddContactActivity extends AppCompatActivity {

    private android.widget.EditText uname;
    private EditText checkinfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
        this.checkinfo = (EditText) findViewById(R.id.check_info);
        this.uname = (EditText) findViewById(R.id.uname);
    }

    public void add1(View v) {
        try {
            EMClient.getInstance().contactManager().addContact(uname.getText().toString(), checkinfo.getText().toString() );
            ToastUtil.showToast(AddContactActivity.this, "添加" + uname.getText() + "成功");
        } catch (HyphenateException e) {
            e.printStackTrace();
            ToastUtil.showToast(AddContactActivity.this, "添加联系人失败" + e.getMessage());
        }
    }

}
