package com.z.hxc.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.hyphenate.EMMessageListener;
import com.hyphenate.chat.EMChatManager;
import com.hyphenate.chat.EMClient;
import com.hyphenate.chat.EMConversation;
import com.hyphenate.chat.EMMessage;
import com.z.hxc.R;
import com.z.hxc.adapter.ChatAdapter;
import com.z.hxc.constant.Constant;
import com.zhy.base.adapter.recyclerview.DividerItemDecoration;

import java.util.ArrayList;
import java.util.List;

public class ChatActivity extends AppCompatActivity implements View.OnClickListener {

    private android.widget.TextView back;
    private android.widget.TextView btnsetting;
    private android.support.v7.widget.RecyclerView rvlist;
    private android.widget.EditText mEditText;
    private android.widget.TextView biaoqing;
    private List<EMMessage> mDatas = new ArrayList<>();
    private EMChatManager mEMChatManager;
    private String uName;
    private TextView send;
    private ChatAdapter mAdapter;
    private EMMessageListener mMsgListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        this.send = (TextView) findViewById(R.id.send);
        this.biaoqing = (TextView) findViewById(R.id.biaoqing);
        this.mEditText = (EditText) findViewById(R.id.msg);
        this.rvlist = (RecyclerView) findViewById(R.id.rv_list);
        this.btnsetting = (TextView) findViewById(R.id.btn_setting);
        this.back = (TextView) findViewById(R.id.back);
        biaoqing.setOnClickListener(this);
        btnsetting.setOnClickListener(this);
        back.setOnClickListener(this);
        send.setOnClickListener(this);

        initData();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mEMChatManager.removeMessageListener(mMsgListener);
    }

    private void initData() {

        Intent intent = getIntent();
        uName = intent.getStringExtra(Constant.CHAT_TO_NAME);
        mEMChatManager = EMClient.getInstance().chatManager();
        EMConversation conversation = mEMChatManager.getConversation(uName);
        if (conversation != null)
            mDatas = conversation.getAllMessages();
        if (null == mDatas) {//如果获取到null的话就重新新建一个list,然后再设置给recycleview
            mDatas = new ArrayList<>();
        }
        mAdapter = new ChatAdapter(getApplicationContext(), mDatas);
        rvlist.setLayoutManager(new LinearLayoutManager(this));
        rvlist.setItemAnimator(new DefaultItemAnimator());
//添加分割线
        rvlist.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.HORIZONTAL_LIST));
        rvlist.setAdapter(mAdapter);
        rvlist.scrollToPosition(mDatas.size()-1);


        mMsgListener = new EMMessageListener() {

            @Override
            public void onMessageReceived(List<EMMessage> messages) {
                //收到消息
                for (EMMessage msg : messages) {
                    mDatas.add(mDatas.size(), msg);
                }

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        mAdapter.notifyDataSetChanged();
                        rvlist.scrollToPosition(mDatas.size() - 1);
                    }
                });

            }

            @Override
            public void onCmdMessageReceived(List<EMMessage> messages) {
                //收到透传消息
            }

            @Override
            public void onMessageReadAckReceived(List<EMMessage> messages) {
                //收到已读回执
            }

            @Override
            public void onMessageDeliveryAckReceived(List<EMMessage> message) {
                //收到已送达回执
            }

            @Override
            public void onMessageChanged(EMMessage message, Object change) {
                //消息状态变动
            }
        };
        EMClient.getInstance().chatManager().addMessageListener(mMsgListener);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_setting:

                break;
            case R.id.back:
                finish();
                break;
            case R.id.biaoqing:
                break;
            case R.id.send:
                EMMessage msg = EMMessage.createTxtSendMessage(mEditText.getText().toString(), uName);
                mEMChatManager.sendMessage(msg);
                mDatas.add(mDatas.size(), msg);
                mAdapter.notifyDataSetChanged();
                rvlist.scrollToPosition(mDatas.size() - 1);
                break;
            default:
                break;
        }
    }
}
