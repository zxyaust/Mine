package com.z.hxc.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.hyphenate.EMContactListener;
import com.hyphenate.chat.EMClient;
import com.hyphenate.exceptions.HyphenateException;
import com.z.hxc.R;
import com.z.hxc.adapter.ChatListAdapter;
import com.z.hxc.utils.ACache;
import com.z.hxc.utils.LogUtil;
import com.z.hxc.utils.ToastUtil;
import com.zhy.base.adapter.recyclerview.DividerItemDecoration;

import java.util.ArrayList;
import java.util.List;

public class ChatListActivity extends AppCompatActivity implements View.OnClickListener {

    private android.widget.TextView back;
    private android.widget.TextView btnsetting;
    private android.support.v7.widget.RecyclerView rvlist;
    private List<String> mDatas = new ArrayList<>();
    private TextView addcontact;
    private TextView notification;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_list);
        this.notification = (TextView) findViewById(R.id.notification);
        this.addcontact = (TextView) findViewById(R.id.add_contact);
        this.rvlist = (RecyclerView) findViewById(R.id.rv_list);
        rvlist.setLayoutManager(new LinearLayoutManager(this));
        rvlist.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL_LIST));
        this.btnsetting = (TextView) findViewById(R.id.btn_setting);
        this.back = (TextView) findViewById(R.id.back);
        back.setOnClickListener(this);
        btnsetting.setOnClickListener(this);
        addcontact.setOnClickListener(this);
        notification.setOnClickListener(this);
        initData();
    }

    private void initData() {
        mDatas = new ArrayList<>();
        EMClient.getInstance().contactManager().setContactListener(new EMContactListener() {
            @Override
            public void onContactAdded(String name) {
                ToastUtil.showToast(ChatListActivity.this,"添加好友"+name+"成功");
            }

            @Override
            public void onContactDeleted(String name) {
                ToastUtil.showToast(ChatListActivity.this,"删除好友"+name+"成功");
            }

            @Override
            public void onContactInvited(String name, String reason) {
                ToastUtil.showToast(ChatListActivity.this,"邀请好友"+name+"成功");
            }

            @Override
            public void onContactAgreed(String name) {
                ToastUtil.showToast(ChatListActivity.this,"请求添加好友"+name+"成功");
            }

            @Override
            public void onContactRefused(String name) {
                ToastUtil.showToast(ChatListActivity.this,name+"拒绝你的好友请求");
            }
        });
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    mDatas = EMClient.getInstance().contactManager().getAllContactsFromServer();
                    LogUtil.d(mDatas.size() + "好友个数");
                } catch (HyphenateException e) {
                    e.printStackTrace();
                    ToastUtil.showToast(ChatListActivity.this, "获取好友出错");
                    LogUtil.e("获取好友出错" + e.toString());
                }
            }
        }).start();

        if (mDatas == null)
            mDatas = new ArrayList<>();
        rvlist.setAdapter(new ChatListAdapter(this, android.R.layout.test_list_item, mDatas));
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.add_contact:
                startActivity(new Intent(this,AddContactActivity.class));
                break;
            case R.id.notification:
                startActivity(new Intent(this,NotifyActivity.class));
                break;
            case R.id.back:
                finish();
                break;
            case R.id.btn_setting:
                break;
            default:
                break;
        }
    }
}
