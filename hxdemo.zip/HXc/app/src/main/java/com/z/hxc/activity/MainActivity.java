package com.z.hxc.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.hyphenate.EMCallBack;
import com.hyphenate.chat.EMClient;
import com.hyphenate.exceptions.HyphenateException;
import com.z.hxc.R;
import com.z.hxc.constant.Constant;
import com.z.hxc.utils.LogUtil;
import com.z.hxc.utils.ToastUtil;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private android.widget.Button btnchat1;
    private android.widget.Button btnchat2;
    private android.widget.Button btnsetting;
    private android.widget.Button btnchatlist;
    private android.widget.EditText uname;
    private android.widget.EditText pwd;
    private Button login;
    private Button regist;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.regist = (Button) findViewById(R.id.regist);
        this.login = (Button) findViewById(R.id.login);
        this.pwd = (EditText) findViewById(R.id.pwd);
        this.uname = (EditText) findViewById(R.id.uname);
        this.btnchatlist = (Button) findViewById(R.id.btn_chatlist);
        this.btnsetting = (Button) findViewById(R.id.btn_setting);
        this.btnchat2 = (Button) findViewById(R.id.btn_chat2);
        this.btnchat1 = (Button) findViewById(R.id.btn_chat1);
        btnchat1.setOnClickListener(this);
        btnchat2.setOnClickListener(this);
        btnsetting.setOnClickListener(this);
        btnchatlist.setOnClickListener(this);
        login.setOnClickListener(this);
        regist.setOnClickListener(this);

    }

    private void login() {
        EMClient.getInstance().login(uname.getText().toString(),pwd.getText().toString(), new EMCallBack() {//回调
            @Override
            public void onSuccess() {
                runOnUiThread(new Runnable() {
                    public void run() {
                        EMClient.getInstance().groupManager().loadAllGroups();
                        EMClient.getInstance().chatManager().loadAllConversations();
                        ToastUtil.showToast(MainActivity.this, "登录成功");
                        LogUtil.d("登录聊天服务器成功！");
                    }
                });
            }

            @Override
            public void onProgress(int progress, String status) {

            }

            @Override
            public void onError(int code, String message) {
                ToastUtil.showToast(MainActivity.this, "登录失败,检查用户名密码或者网络");
                LogUtil.d("登录聊天服务器失败！");
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.login:
                login();
                break;
            case R.id.regist:
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            EMClient.getInstance().createAccount(uname.getText().toString(),pwd.getText().toString());
                            ToastUtil.showToast(MainActivity.this,"创建成功");
                        } catch (HyphenateException e) {
                            e.printStackTrace();
                            ToastUtil.showToast(MainActivity.this,"创建失败"+e.getMessage());
                        }
                    }
                }).start();

                break;
            case R.id.btn_chat1:
                Intent intent = new Intent(this,ChatActivity.class);
                intent.putExtra(Constant.CHAT_TO_NAME,"1234");
                startActivity(intent);
                break;
            case R.id.btn_chat2:
                Intent intent1 = new Intent(this,ChatActivity.class);
                intent1.putExtra(Constant.CHAT_TO_NAME,"5678");
                startActivity(intent1);
                break;
            case R.id.btn_setting:
                startActivity(new Intent(this,AddContactActivity.class));
                break;
            case R.id.btn_chatlist:
                startActivity(new Intent(this,ChatListActivity.class));
                break;
            default:
                break;
        }
    }
}
