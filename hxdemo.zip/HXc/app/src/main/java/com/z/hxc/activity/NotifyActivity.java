package com.z.hxc.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.z.hxc.R;

public class NotifyActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notify);
    }
}
