package com.z.hxc.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.View;

import com.z.hxc.activity.ChatActivity;
import com.z.hxc.constant.Constant;
import com.zhy.base.adapter.ViewHolder;
import com.zhy.base.adapter.recyclerview.CommonAdapter;

import java.util.List;

/**
 * Created by z on 2016/5/26.
 */
public class ChatListAdapter extends CommonAdapter<String> {

    private Context mContext;

    public ChatListAdapter(Context context, int layoutId, List<String> datas) {
        super(context, layoutId, datas);
        mContext = context;
    }

    @Override
    public void convert(ViewHolder holder, final String s) {
        holder.setText(android.R.id.text1, s);
        holder.setOnClickListener(android.R.id.text1, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, ChatActivity.class);
                intent.putExtra(Constant.CHAT_TO_NAME, s);
                mContext.startActivity(intent);
            }
        });
    }
}
