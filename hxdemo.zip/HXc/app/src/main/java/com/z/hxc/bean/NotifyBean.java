package com.z.hxc.bean;

/**
 * Created by z on 2016/5/26.
 */
public class NotifyBean {
    public String uName;
    public String statu;
}
