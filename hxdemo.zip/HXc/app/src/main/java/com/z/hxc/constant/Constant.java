package com.z.hxc.constant;

/**
 * Created by z on 2016/5/26.
 */
public interface Constant {
    String CHAT_TO_NAME = "CHAT_TO_NAME";
}
