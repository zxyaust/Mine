package com.z.hxc.utils;

import android.app.Activity;
import android.content.Context;
import android.os.Looper;
import android.widget.Toast;

/**
 * Created by z on 2016/5/24.
 */
public class ToastUtil {
    /**
     * 子线程也可以toast,内部进行了处理
     */
    public static void showToast(final Activity activity, final String s) {
        Thread thread = Looper.getMainLooper().getThread();
        boolean isUIthread = Thread.currentThread() == thread;
        if (isUIthread) {
            Toast.makeText(activity.getApplicationContext(), s, Toast.LENGTH_SHORT).show();
        } else {
            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(activity.getApplicationContext(), s, Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    /**
     * 只能在主线程中使用
     */
    public static void showToast(Context context, final String s) {
        Toast.makeText(context, s, Toast.LENGTH_SHORT).show();
    }

}
